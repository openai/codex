The files in this folder were copied verbatim from [librustdoc/html/templates] in version
eeb59f16a5f40e14dc29b95155b7f2569329e3ec. Dual licensed under MIT OR Apache-2.0.

Please find the authors in [their Git history].

[librustdoc/html/templates]: <https://github.com/rust-lang/rust/tree/master/src/librustdoc/html/templates>
[their Git history]: <https://github.com/rust-lang/rust/commits/master/src/librustdoc/html/templates>
