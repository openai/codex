#![cfg(all(windows, feature = "std"))]
#[path = "std_windows/mod.rs"]
mod std_windows;
