# icu_decimal_data [![crates.io](https://img.shields.io/crates/v/icu_decimal_data)](https://crates.io/crates/icu_decimal_data)

<!-- cargo-rdme start -->

Data for the `icu_decimal` crate

This data was generated with CLDR version 48.0.0, ICU version release-78.1rc, and
LSTM segmenter version v0.1.0.

<!-- cargo-rdme end -->

## More Information

For more information on development, authorship, contributing etc. please visit [`ICU4X home page`](https://github.com/unicode-org/icu4x).
