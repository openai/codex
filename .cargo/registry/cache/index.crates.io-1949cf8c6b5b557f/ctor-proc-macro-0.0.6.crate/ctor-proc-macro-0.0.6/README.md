# Support crate only

This crate is not intended to be used directly and does not have any public exports.

See [ctor](https://crates.io/crates/ctor) and [dtor](https://crates.io/crates/dtor) on [crates.io](https://crates.io) for the main crates.
