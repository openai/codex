import { defineConfig } from 'vite';

// Provide a stub Vite config in the CLI package to avoid resolving a parent-level vite.config.js
export default defineConfig({});